# Vamsis Woodside Website

This folder contains the static website and assets for Vamsis Woodside.

## Preview
Open `index.html` in a browser. The page uses browser-imported React and Tailwind CDN assets, so internet access is needed for those dependencies.

## GitHub Pages deployment
The workflow at `.github/workflows/static.yml` deploys the repository root to GitHub Pages whenever changes are pushed to `main`, or when manually triggered from the Actions tab.

In GitHub, open **Settings → Pages** and select **GitHub Actions** as the deployment source if it is not already selected.
